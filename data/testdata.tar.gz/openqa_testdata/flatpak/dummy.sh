#!/bin/sh

echo "Dummy flatpak: version 1."
